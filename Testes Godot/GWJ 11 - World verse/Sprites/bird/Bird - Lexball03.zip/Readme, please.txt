Do you want more cheap gameart? Here is the full package of birds enemies. Please, visit:

https://www.gamedevmarket.net/asset/flying-enemies-and-free-assets-3279/

It also includes a free repeatable tile and more... take a look!